export { default } from './Lottery'
