export default {
  cake: {
    56: '0x04958ceb50f40ed25f0b250f66b51fc4f820f6c7',
    97: '',
  },
  pasta: {
    56: '0x04958ceb50f40ed25f0b250f66b51fc4f820f6c7',
    97: '',
  },
  masterChef: {
    56: '0x60b1bc3B8F753758CaB89d4603BF5C901Dd16EB4',
    97: '',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '',
  },
  lottery: {
    56: '0x3d0533a088f73840ba90FcE083844d2A22e15A75',
    97: '',
  },
  lotteryNFT: {
    56: '0x12ee38f53d21707835f2d0Be3cd402AD7F91Bf7c',
    97: '',
  },
  mulltiCall: {
    56: '0xE0efA311729d4374Ce9545da6ba18BB587bf934B',
    97: '0x67ADCB4dF3931b0C5Da724058ADC2174a9844412',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '',
  },
}
